import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appt = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appt);
    }

    @Test
    public void testDuplicateAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appt = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appt);

        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(appt));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appt = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appt);
        service.deleteAppointment("1");
    }
}
