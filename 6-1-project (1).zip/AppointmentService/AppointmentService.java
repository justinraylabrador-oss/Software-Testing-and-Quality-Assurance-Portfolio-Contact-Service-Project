import java.util.HashMap;

public class AppointmentService {

    private HashMap<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException();
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    public void deleteAppointment(String id) {
        appointments.remove(id);
    }
}
