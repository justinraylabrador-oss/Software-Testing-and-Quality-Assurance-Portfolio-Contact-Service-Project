import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTask() {
        Task task = new Task("1", "Homework", "Finish assignment");
        assertEquals("Homework", task.getName());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task(null, "Homework", "Finish assignment"));
    }

    @Test
    public void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("1", "ThisNameIsWayTooLongForRequirement",
                        "Description"));
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("1", "Homework",
                        "This description is way too long and should definitely throw an exception because it exceeds fifty characters."));
    }
}
