import java.util.HashMap;

public class TaskService {

    private HashMap<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId()))
            throw new IllegalArgumentException();
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String id) {
        tasks.remove(id);
    }

    public void updateName(String id, String name) {
        tasks.get(id).setName(name);
    }

    public void updateDescription(String id, String description) {
        tasks.get(id).setDescription(description);
    }
}
