import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact c = new Contact("1", "John", "Doe",
                "1234567890", "Address");
        service.addContact(c);
    }

    @Test
    public void testDuplicateContact() {
        ContactService service = new ContactService();
        Contact c = new Contact("1", "John", "Doe",
                "1234567890", "Address");
        service.addContact(c);

        assertThrows(IllegalArgumentException.class, () ->
                service.addContact(c));
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact c = new Contact("1", "John", "Doe",
                "1234567890", "Address");
        service.addContact(c);
        service.updateFirstName("1", "Mike");
        assertEquals("Mike", c.getFirstName());
    }
}
