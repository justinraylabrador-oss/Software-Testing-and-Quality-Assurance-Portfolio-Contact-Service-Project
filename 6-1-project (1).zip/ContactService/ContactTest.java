import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testValidContact() {
        Contact c = new Contact("1", "John", "Doe",
                "1234567890", "123 Main St");
        assertEquals("John", c.getFirstName());
    }

    @Test
    public void testInvalidId() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "John", "Doe",
                        "1234567890", "123 Main St"));
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Doe",
                        "123", "123 Main St"));
    }
}
