import java.util.HashMap;

public class ContactService {

    private HashMap<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Duplicate ID");
        }
        contacts.put(contact.getContactId(), contact);
    }

    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    public void updateFirstName(String id, String firstName) {
        contacts.get(id).setFirstName(firstName);
    }

    public void updateLastName(String id, String lastName) {
        contacts.get(id).setLastName(lastName);
    }

    public void updatePhone(String id, String phone) {
        contacts.get(id).setPhone(phone);
    }

    public void updateAddress(String id, String address) {
        contacts.get(id).setAddress(address);
    }
}
